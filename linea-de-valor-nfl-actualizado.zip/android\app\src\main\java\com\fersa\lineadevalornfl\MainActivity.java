package com.fersa.lineadevalornfl;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
